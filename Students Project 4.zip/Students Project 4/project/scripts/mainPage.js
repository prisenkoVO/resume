window.onload = () => {
    var comments = document.querySelectorAll('.material-icons.comment');
    console.log('fire', comments.length);
    for (let i = 0; i < comments.length; i++)
    {
        comments[i].addEventListener('click', function () {
            var selectedobj = document.querySelectorAll('#showthis');
    
            if (selectedobj[i].className == 'hide')
            {  //check if classname is hide 
                selectedobj[i].style.display = "block";
                selectedobj[i].className = 'show';
            } else {
                selectedobj[i].style.display = "none";
                selectedobj[i].className = 'hide';
            }
        });
    }
}


