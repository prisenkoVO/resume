'use strict'
// Toggle menu  bar4
let modalWindowOpen = false;

let filterToggle = false;

menuToggle.addEventListener('change', evt => {
    const checked = evt.target.checked;  // get checkbox state
    const menu = $('.menu'); // Menu sidebar
    const menuBorderTriangle = $('.avatar-icon');

    if (checked) {
        menu.style.display = 'block';
        menu.style.opacity = '1';
    } else {
        menu.style.opacity = '0';
        setTimeout(() => {
            menu.style.display = 'none';
        }, 550)
    }
    
    menuBorderTriangle.classList.toggle('avatar-triangle', checked);
});

// Modal window events start

function blockBodyScroll() {
    if (modalWindowOpen === true)
        document.body.style.overflowY = "hidden";
    else
        document.body.style.overflowY = "visible";
}; 

function closeModalWindow() {
    modalWindow.style.display = "none";
    modalWindowOpen = false;
    blockBodyScroll();
};

window.addEventListener("keyup", (event) => {
    if (event.key === "Escape" && modalWindowOpen === true)
        closeModalWindow();
});

window.addEventListener("click", (event) => {
    if (event.target === modalWindow) {
        modalWindow.style.display = "none"; 
        modalWindowOpen = false;
        blockBodyScroll();
    }
});

closeButton.addEventListener("click", closeModalWindow);
// Modal window events end

// Filter events start
filterIcon.addEventListener('click', () => {
    filterToggle = !filterToggle ;

    if (filterToggle) {
        filterSection.style.display = 'block';
    } else {
        filterSection.style.display = 'none';
    }
});

const setRandomPreloadersColor = () => {
    console.log(preloaders)
    const preloaderColors = ['primary', 'success', 'info'];
    const randomColor = Math.floor(Math.random() * preloaderColors.length);
    const preloaderClass = `text-${preloaderColors[randomColor]}`;
    preloaders.forEach(preloader => preloader.classList.add(preloaderClass));
}
setRandomPreloadersColor();
