const filterSection = $('.page_filter');
const filterIcon = $('.filter-icon');
const menuToggle = $('#menu_toggle'); // checkbox for toggle
const modalWindow = $(".modal-window");
const closeButton = $(".modal-window__center__close");
const addNewsSubmitButton = $('.news-form button[type="submit"]');
const submitPostButton = $('.submitPost'); // Submit post button
const submitPostForm = $('.news-form'); // Submit post form
const addNewsFormTitle = $('.news-form input');
const addNewsFormFields = $All('.news-form > span');
const openWindow = $All(".card");
const modalWindowGeneral = $(".modal-window__general-block");
const modalWindowRaiting = $(".modal-window__raiting");
const modalWindowCenter = $('.modal-window__center');
const closeWindow = $(".modal-window__center__close");
const preloaders = $All('.preloader'); // All preloaders in page
