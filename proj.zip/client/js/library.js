// JavaScript source code
var acc = document.getElementsByClassName("accordeon");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function () {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        panel.style.maxHeight === null ? panel.style.maxHeight = panel.scrollHeight + 'px'
        : panel.style.maxHeight = null;
    });
}