    'use strict'
    // TODO: add input title max charachters ( 109 )
    //Requirements : Toggle news button, toggle smil
    // Set display of the element to none or make it visible
    const toggleForm = (form, formDisplay) => {
        const hidden = getComputedStyle(form, null).display;
        hidden === 'none' ? form.style.display = formDisplay : form.style.display = 'none';
    };

    submitPostButton.addEventListener('click', () => {
        toggleForm(submitPostForm, 'flex');
    });


    // TOGGLE EMOJI SECTION 
    let prevEmojiToggled;

    const emojisClickHandler = (elem) => {
        const _emojis = elem.querySelectorAll('span')
        _emojis.forEach(emoji => {
            emoji.addEventListener('click', () => {
                elem.children[0].value += emoji.innerText
            })
        })
    };

    const toggleEmoji = (elem) => {
        const emojis = $('.emojis')
        if (elem === prevEmojiToggled) {
            emojis.style.display = 'none'
            prevEmojiToggled = undefined
        } else {
            const _emojis = emojis.cloneNode(true)
            _emojis.style.display = 'flex'
            emojis.remove()
            elem.appendChild(_emojis)
            emojisClickHandler(elem)
            prevEmojiToggled = elem
        }
    };

    addNewsFormFields.forEach(elem => {
        elem.addEventListener('click', (evt) => {

            if (evt.target.classList.contains('emoji-toggle')) {
                toggleEmoji(elem)
            }
        })
    });


addNewsFormTitle.addEventListener('keydown', (evt) => {
    const lastChar = value[value.length - 1];
    const { value } = evt.target;

    if (value.length >= 19) {
        evt.target.value = value.substr(0, 18);
    }
})

addNewsFormTitle.addEventListener('click', (evt) => console.log('Hello'))
