﻿const openWindow = document.querySelectorAll(".card")
const modalWindow = document.querySelector(".modal-window")
const modalWindowGeneral = document.querySelector(".modal-window__general-block")
const modalWindowRaiting = document.querySelector(".modal-window__raiting")
const modalWindowCenter = $('.modal-window__center')
const closeWindow = document.querySelector(".modal-window__center__close")
let modalWindowOpen = false;


function block_window(bul_variable) {
    if (bul_variable == true)
        document.body.style.overflowY = "hidden";
    else
        document.body.style.overflowY = "visible";
};
function closeModalWindow() {
    modalWindow.style.display = "none";
    modalWindowOpen = false
    block_window(modalWindowOpen)
}


openWindow.forEach(elem => elem.addEventListener("click", (event) => {
    if (event.target.tagName != 'I') {
        if (document.querySelector('.modal-window__general-block p').innerText.split('').length > 1000) {
            modalWindow.style.display = "block"
            modalWindowOpen = true
            block_window(modalWindowOpen)
        }
        else {
            modalWindow.style.display = "block"
            modalWindowGeneral.style.height = '30vh'
            modalWindowRaiting.style.top = '55vh'
            modalWindowCenter.style.height = '50vh'
            modalWindowOpen = true
            block_window(modalWindowOpen)
        }
    }
}))


window.addEventListener("keyup", (event) => {
    if (event.key == "Escape" && modalWindowOpen == true)
        closeModalWindow(modalWindowOpen)
})

window.addEventListener("click", (event) => {
    if (event.target == modalWindow) {
        modalWindow.style.display = "none";
        modalWindowOpen = false
        block_window(modalWindowOpen)
    }
})

closeWindow.addEventListener("click", closeModalWindow)