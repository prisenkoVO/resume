'use strict'

const injectNews = (news) => {
    $('main .preloader').style.display = 'none';
    
    news.forEach(post => {
        const postBlock = document.createElement('div');
        postBlock.className += 'card mb-3 ml-3 p-3 pointer shadow element-hover rounded';
        postBlock.innerHTML = `<div class="row no-gutters">
        <i class="material-icons favorite">
            star_border
        </i>
        <div class="col-md-4 news__card-background">

        </div>
        <div class="col-md-8">
            <div class="card-body">
                <h5 class="card-title">${post.title}</h5>
                <p class="card-text">
                    ${post.text}
                </p>
                <p class="card-text"><small class="text-muted">${post.date}</small></p>
                <p class="card-text"><small class="text-muted">${post.author}</small></p>
            </div>
        </div>
    </div>`;
    $('main').appendChild(postBlock);
    });
}

// Fetch all news from db on mainPage
fetch('http://localhost:54677/api/news/get')
    .then(res => res.json())
    .then(res => {
        injectNews(res)
    })
    .catch(err => console.log(err))