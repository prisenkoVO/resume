const index = {
    links: ['mainPage'],
    html: `<div class="page_container">
    
    <div class="content_container">
        <aside class="page_filter">
            <div class="filter">
                <div class="filter__title">
                    <span>
                        <h2>Фильтры</h2>
                    </span>
                </div>
                <!-- class="block" -->
                <div class="filter__option">
                    <input type="checkbox" id="filter1" />
                    <label for="filter1">
                        <text>Все новости</text>
                    </label>
                </div>
                <div class="filter__option">
                    <input type="checkbox" id="filter2" />
                    <label for="filter2">
                        <text>События</text>
                    </label>
                </div>
                <div class="filter__option">
                    <input type="checkbox" id="filter3" />
                    <label for="filter3"><text>Истории</text></label>
                </div>
                <div class="filter___title">
                    <span>
                        <h4>Отделы</h4>
                    </span>
                </div>
                <div class="filter__option">
                    <input type="checkbox" id="filter5" />
                    <label for="filter5"><text>IT</text></label>
                </div>
                <div class="filter__option">
                    <input type="checkbox" id="filter6" />
                    <label for="filter6"><text>Бизнес школа</text></label>
                </div>
                <div class="filter__option">
                    <input type="checkbox" id="filter7" />
                    <label for="filter7"><text>INGOSCODE</text></label>
                </div>
            </div>
        </aside>
        <main class="col-6 mr-2 d-flex justify-content-center align-items-center">
            <div class="news">
                <button class="button elemen    t-hover rounded submitPost">Предложить новость</button>
                <form class="news-form rounded">
                    <h4>Поделись своими впечатлениями !</h4>
                    <span class="news-form__title emoji-toggle">
                        <input type="text" name="news-title" placeholder="Заголовок новости" class="rounded shadow element-hover" autocomplete="off" maxlength="19" />
    
                        <div class="emojis rounded">
                            <span>😂</span>
                            <span>😔</span>
                            <span>💖</span>
                            <span>👍</span>
                            <span>💪</span>
                            <span>💯</span>
                            <span>🤔</span>
                            <span>🖨️</span>
                            <span>👔</span>
                            <span>💻</span>
                        </div>
                    </span>
    
                    <span class="news-form__body emoji-toggle">
                        <textarea rows="10" cols="35" placeholder="Тело новости" class="rounded shadow element-hover" autocomplete="off"></textarea>
                    </span>
    
                    <button type="submit" class="element-hover send"> Отправить </button>
                </form>
            </div>
            <div class="card mb-3 ml-3 p-3 pointer shadow element-hover rounded">
                <div class="row no-gutters">
                    <i class="material-icons favorite">
                        star_border
                    </i>
                    <div class="col-md-4 news__card-background">
    
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">
                                This is a wider card with supporting text below as a natural lead-in to
                                additional
                                content. This content is a little bit longer.
                            </p>
                            <p class="card-text"><small class="text-muted">29 июля 2019</small></p>
                            <p class="card-text"><small class="text-muted">Иван Иванов</small></p>
                        </div>
                    </div>
                </div>
            </div>
    
    
    
    </div>
    
    <!--Button "go to top"-->
    <a class="back_to_top" title="Наверх">
        <i class="material-icons filter__button-top-page">keyboard_arrow_up</i>
    </a>
    </main>
    </div>
    `,
    scripts: ['mainPageScript', 'mainPage']
} 

const library = {
    links: ['library'],
    html : `<aside class="page_filter">
    <div class="filter">

    </div>
</aside>
<main>
    <h1>Полезные материалы</h1>
    <div class="materials_info">
        <p>
            В этом разделе вы найдете информацию о методах диагностики и лечения,
            которые мы успешно применяем, сможете познакомиться с книгами, брошюрами, статьями и памятками,
            составленными высокопрофессиональными специалистами клиники АО «Медицина».
        </p>
    </div>
    <ul class="library_navigation">
        <li><a class="active" href="#">Документы</a></li>
        <li><a href="#">Статьи</a></li>
        <li><a href="#">Журналы</a></li>
        <li><a href="#">Публикации</a></li>
    </ul>
    <div class="materialls_accordeon">
        <button class="accordeon">Section 1</button>
        <div class="panel">
            <ul>
                <li><a href="#">first document</a></li>
                <li><a href="#">second document</a></li>
                <li><a href="#">third document</a></li>

            </ul>
        </div>

        <button class="accordeon">Section 2</button>
        <div class="panel">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>

        <button class="accordeon">Section 3</button>
        <div class="panel">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
    </div>
</main>`,
    scripts: ['toTopButton'],
}

const pages = {
    index,
    library    
}

console.log(pages)

