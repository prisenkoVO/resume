﻿'use strict'
const addPostButton = $('.news-form button[type="submit"]');
console.log(submitPostButton)