function trackScroll() {
    const scrolled = window.pageYOffset
    const coords = document.documentElement.clientHeight
    const goTopBtn = $('.back_to_top')

    if (scrolled > 200) {
        goTopBtn.classList.add('back_to_top-show')
    }
    if (scrolled < 200) {
        goTopBtn.classList.remove('back_to_top-show')
    }
}

function backToTop() {
    if (window.pageYOffset > 0) {
        window.scrollBy(0, -80)
        setTimeout(backToTop, 0)
    }
}

window.addEventListener('scroll', trackScroll)
document.querySelector('.back_to_top').addEventListener('click', backToTop)