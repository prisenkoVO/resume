// File with utility functions 
const $ = (selector) => document.querySelector(selector)

const $All = (selector) => document.querySelectorAll(selector)
