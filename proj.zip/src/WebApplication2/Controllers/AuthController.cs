﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
namespace WebApplication2.Controllers
{
    using Models;
    using Services;
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AuthService authService;
        public AuthController()
        {
            this.authService = new AuthService();
        }

        [HttpGet]
        public ActionResult<string> StarPage()
        {
            HttpContext.Session.SetString("FirstName", "name");
            return JsonConvert.SerializeObject(HttpContext.Session.GetString("FirstName"));

        }
        [HttpPost]
        public ActionResult<object> LogIn(object userData)
        {
            try
            {
                var user = JsonConvert.DeserializeObject<User>(userData.ToString()) ?? throw new Exception("Некорректные данные");
                HttpContext.Session.SetString("FirstName", authService.ChechForAvaliability(user).ToString());
                return JsonConvert.SerializeObject(authService.ChechForAvaliability(user));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        [Route("logout")]
        public ActionResult<string> Logout()
        {
            HttpContext.Session.Clear();
            return JsonConvert.SerializeObject("Logout");
        }
    }
}