﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using WebApplication2.Models;
using Microsoft.AspNetCore.Hosting;


namespace WebApplication2.Controllers
{
    public class ImageController : ControllerBase
    {

        //[HttpPost]
        //public async Task<IActionResult> Index(Image image)
        //{
        //    if (image.image.Length > 0)
        //    {
        //        var filename = Path.GetFileName(image.image.FileName);
        //        using (var stream = new FileStream(path, FileMode.Create))
        //        {
        //            await picture.File.CopyToAsync(stream);
        //        }
        //    }

        //    string StartDirectory = @"c:\Users\exampleuser\start";
        //    string EndDirectory = @"c:\Users\exampleuser\end";

        //    foreach (string filename in Directory.EnumerateFiles(StartDirectory))
        //    {
        //        using (FileStream SourceStream = File.Open(filename, FileMode.Open))
        //        {
        //            using (FileStream DestinationStream = File.Create(EndDirectory + filename.Substring(filename.LastIndexOf('\\'))))
        //            {
        //                await SourceStream.CopyToAsync(DestinationStream);
        //            }
        //        }
        //    }

        //    return View();
        //}
    }
}