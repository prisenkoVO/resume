﻿using System;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace WebApplication2.Controllers
{
    using Services;
    using Mocks;



    [Route("api/users")]
    [ApiController]
    public class InternController : ControllerBase
    {
        private readonly UsersService _users;

        public InternController()
        {
            this._users = new UsersService();
        }


        [HttpGet]
        [Route("")]
        public ActionResult<string> GetUsers()
        {
            var result = this._users.GetUsers();
            return Ok(result);
            //this.mockInterns = new MockInterns();
            // return JsonConvert.SerializeObject(mockInterns.AllInterns);
        }

        [HttpGet]
        [Route("roles/{roleId}")]
        public ActionResult<string> GetUsersByRole(string roleId)
        {
            try
            {
                var userRoleId = long.TryParse(roleId, out long id) ? id : throw new Exception("Не корректный Id");

                var result = this._users.GetUsersByRole(userRoleId);
                return Ok(result);
                //return JsonConvert.SerializeObject(mockInterns.AllInterns);
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            };
        }
    }
}