﻿using Microsoft.AspNetCore.Mvc;
using WebApplication2.Models;
using System.IO;
using System;
using Newtonsoft.Json;

namespace WebApplication2.Controllers
{
    using Services;

    [ApiController]
    [Route("api/news")]
    public class NewsController : ControllerBase
    {
        static readonly string ServerUploadFolder = Path.GetTempPath();
        private readonly NewsService _newsService;

        public NewsController()
        {
            this._newsService = new NewsService();
        }

        // GET api/values
        [HttpGet]
        [Route("get")]
        public ActionResult<string> GetNews()
        {
            return JsonConvert.SerializeObject(this._newsService.GetNews());
        }

        [HttpPost]
        [Route("Post")]
        public void PostNews(object json)
        {
            var str = JsonConvert.DeserializeObject<News>(json.ToString());
            this._newsService.AddNews(str);
        }

        /*
        [HttpPost]
        public async Task<FileResult> UploadFile()
        {
        }
        */
    }
}