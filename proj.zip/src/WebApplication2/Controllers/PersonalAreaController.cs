﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WebApplication2.Mocks;

namespace WebApplication2.Controllers
{
    using Services;
    [Route("api/personalarea")]
    [ApiController]
    public class PersonalAreaController : ControllerBase
    {
        private PersonalAreaService personalAreaService;

        public PersonalAreaController()
        {
            this.personalAreaService = new PersonalAreaService();
        }

        [HttpGet]
        public ActionResult<string> GetUserData()
        {
            return JsonConvert.SerializeObject(personalAreaService.GetUsers());
        }
    }
}