﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WebApplication2.Mocks;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SettingController : ControllerBase
    {
        static readonly string ServerUploadFolder = Path.GetTempPath();

        // GET api/setting
        private MockSetting mockUsers;

        [HttpGet]
        public ActionResult<string> GetUser()
        {
            this.mockUsers = new MockSetting();
            return JsonConvert.SerializeObject(mockUsers.AllUsers);
        }
        [HttpPost]
        public void PostUser(User user)
        {
            string json = user.ToString();
            News news = JsonConvert.DeserializeObject<News>(json);
        }

    }
}