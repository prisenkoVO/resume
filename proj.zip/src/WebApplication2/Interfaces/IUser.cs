﻿using System.Collections.Generic;
using WebApplication2.Models;

namespace WebApplication2.Interfaces
{
    public interface IUser
    {
        IEnumerable<User> AllUsers { get; }
    }
}
