﻿using System;
using System.Collections.Generic;
using System.Linq;
using WebApplication2.Models;

namespace WebApplication2.Mocks
{
    using Interfaces;

    public class MockNews
    {
        protected static readonly List<News> ListOfNews = new List<News> {new News
        {
            Photo = "",
            Title = "First article",
            Text =
                "Feet evil to hold long he open knew an no. Apartments occasional boisterous as solicitude to introduced. Or fifteen covered we enjoyed demesne is in prepare. In stimulated my everything it literature. Greatly explain attempt perhaps in feeling he. House men taste bed not drawn joy. Through enquire however do equally herself at. Greatly way old may you present improve. Wishing the feeling village him musical. ",
            Date = "9 August 2019",
            Author = "Mary NNN",
            Star = false
        }, new News
        {
            Photo = "",
            Title = "Second article",
            Text =
                "In it except to so temper mutual tastes mother. Interested cultivated its continuing now yet are. Out interested acceptance our partiality affronting unpleasant why add. Esteem garden men yet shy course. Consulted up my tolerably sometimes perpetual oh. Expression acceptance imprudence particular had eat unsatiable. ",
            Date = "9 May 2019",
            Author = "Mike NNN",
            Star = true
        },new News
        {
            Photo = "",
            Title = "Second article",
            Text =
                "In it except to so temper mutual tastes mother. Interested cultivated its continuing now yet are. Out interested acceptance our partiality affronting unpleasant why add. Esteem garden men yet shy course. Consulted up my tolerably sometimes perpetual oh. Expression acceptance imprudence particular had eat unsatiable. ",
            Date = "9 May 2019",
            Author = "Mike NNN",
            Star = true
        },
            new News
            {
                Photo = "",
                Title = "Fourth article",
                Text =
                    "Not far stuff she think the jokes. Going as by do known noise he wrote round leave. Warmly put branch people narrow see. Winding its waiting yet parlors married own feeling. Marry fruit do spite jokes an times. Whether at it unknown warrant herself winding if. Him same none name sake had post love. An busy feel form hand am up help. Parties it brother amongst an fortune of. Twenty behind wicket why age now itself ten. ",
                Date = "9 August 2019",
                Author = "Erik NNN",
                Star = true
            }
        };

        public IEnumerable<News> AllNews
        {
            get => ListOfNews;
        }

    };
}