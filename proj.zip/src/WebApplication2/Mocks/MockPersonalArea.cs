﻿    using System.Collections.Generic;
using WebApplication2.Interfaces;
using WebApplication2.Models;

namespace WebApplication2.Mocks
{
    public class MockPersonalArea : IPersonalArea
    {
        private MockUser interns;
        public MockPersonalArea()
        {
            this.interns = new MockUser();
        }
        public IEnumerable<PersonalArea> AllPersonalData {
            get
            {
                return new List<PersonalArea>
                {
                    new PersonalArea{
                        Name ="Name1",
                        SecondName = "SeconfName2",
                        Department ="IT",
                        Email = "personal@ingos.ru",
                        Rank = 4.8,
                        Teammates = interns.AllUsers},
                    new PersonalArea{
                        Name ="Name1",
                        SecondName = "SeconfName2",
                        Department ="IT",
                        Email = "personal@ingos.ru",
                        Rank = 4.8,
                        Teammates = interns.AllUsers},
                    new PersonalArea{
                        Name ="Name1",
                        SecondName = "SeconfName2",
                        Department ="IT",
                        Email = "personal@ingos.ru",
                        Rank = 4.8,
                        Teammates = interns.AllUsers}
                };
            }
        }
    }
}
