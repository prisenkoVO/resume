﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Mocks
{
    using Models;
    using Interfaces;
    public class MockSetting: IUser
    {
        public IEnumerable<User> AllUsers
        {
            get
            {
                return new List<User>
                {
                    new User {
                        Photo = "",
                        FirstName = "myname1",
                        LastName = "lastname",
                        Gender = "male",
                        Birth = "10.10.1000",
                        Phone = "+799999999",
                        Email = "index@mail.ru",
                        City = "City",
                        Office = "Office"
                    },
                    new User {
                        Photo = "",
                        FirstName = "myname1",
                        LastName = "lastname",
                        Gender = "male",
                        Birth = "10.10.1000",
                        Phone = "+799999999",
                        Email = "index@mail.ru",
                        City = "City",
                        Office = "Office"
                    }
                };
            }
        }
    }
}
