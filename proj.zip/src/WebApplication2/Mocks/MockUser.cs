﻿using System.Collections.Generic;
using WebApplication2.Interfaces;
using WebApplication2.Models;

namespace WebApplication2.Mocks
{
    public class MockUser: IUser
    {
        public IEnumerable<User> AllUsers
        {
            get
            {
                return new List<User>
                {
                    new User{FirstName="Name1",Team="team1",Rank=6.3,Password = "aaa111" },
                    new User{FirstName="Name2",Team="team2",Rank=5.3,Password = "bbb222"},
                    new User{FirstName="Name3",Team="team3",Rank=4.3, Password = "ccc333" },
                    new User{FirstName="Name4",Team="team4",Rank=6.3,Password = "admin" }
                };
            }
        }
    }
}
