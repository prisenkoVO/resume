﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;


namespace WebApplication2.Models
{
    public class Image
    {
        public IFormFile image { get; set; }
    }
}
