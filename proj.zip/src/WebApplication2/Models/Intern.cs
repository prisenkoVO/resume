﻿using System.Collections.Generic;

namespace WebApplication2.Models
{
    public class Intern : User
    {
       public List<User> Mentors { get; set; }
    }
}
