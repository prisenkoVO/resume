﻿using System.Collections.Generic;


namespace WebApplication2.Models
{
    public class Mentor : User
    {
        public List<User> Students { get; set; }
    }
}
