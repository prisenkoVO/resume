﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models
{
    public class User
    {
        public long Id { get; set; }
        public string Photo { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string  Gender { get; set; }
        public string Birth { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string City { get; set; }
        public string Office { get; set; }
        public string Team { get; set; }
        public double Rank { get; set; }
        public string Password { get; set; }
        public List<Role> Roles { get; set; }
    }
}

