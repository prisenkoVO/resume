﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Services
{
    using Mocks;
    using Models;
    public class AuthService
    {
        private readonly MockUser mockUser;
        public AuthService()
        {
            this.mockUser = new MockUser();
        }
        public object ChechForAvaliability(User user)
        {
            var usr = mockUser.AllUsers;
            int i = 0;
            foreach (var u in usr)
            {
                if (u.FirstName == user.FirstName && u.Password == user.Password)
                {
                    return usr.ToList()[i].Id;
                }
                i++;
            }
            return "Такого пользователя не существует";
        }
    }
}