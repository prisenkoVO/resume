﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace WebApplication2.Services
{
    public class ChatBotServices
    {
        public static string Collector(string[] str)
        {
            string fullstr = "";
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i].Length > 0 && i != str.Length - 1 && str[i] != " ")
                    fullstr += str[i] + " ";
                else if (str[i].Length > 0 && i == str.Length - 1)
                    fullstr += str[i];
            }
            return fullstr;
        }
        public static string Bot(string str)
        {
            str = str.ToLower().Replace('ё', 'е');
            char[] alpha = new char[] { 'й', 'ц', 'у', 'к', 'е', 'н', 'г', 'ш', 'щ', 'з', 'х', 'ъ', 'ф', 'ы', 'в', 'а', 'п', 'р', 'о', 'л', 'д', 'ж', 'э', 'я', 'ч', 'с', 'м', 'и', 'т', 'ь', 'б', 'ю' };

            //замена всех символов на пробел, которые не входят в массив alpha
            foreach (char c in str)
            {
                bool mybool = true;
                foreach (char c2 in alpha)
                {
                    if (c2 == c)
                    {
                        mybool = false;
                        break;
                    }
                }
                if (mybool)
                    str = str.Replace(c, ' ');
            }
            string[] arrayStr = str.Split(' ');

            //Замена всех пробелов на пустоту
            for (int i = 0; i < arrayStr.Length; i++)
            {
                if (arrayStr[i].Length == 0)
                    arrayStr[i] = "";
            }

            //Команды 

            //вариации приветсвия
            string[] hello = new string[] { "привет", "хай", "Здравствуй", "Приветствую" };
            for (int i = 0; i < hello.Length; i++)
            {
                for (int j = 0; j < arrayStr.Length; j++)
                {
                    if (arrayStr[j] == hello[i])
                    {
                        arrayStr[j] = "";
                        return "Привет!\n" + Bot(Collector(arrayStr));
                    }
                }
            }

            //Вариации как дела
            string[] how = new string[] { "дела", "делишки", "оно", "настроение" };
            bool howbool = false;
            //находим ключевое слово "как"
            for (int i = 0; i < arrayStr.Length; i++)
            {
                if (arrayStr[i] == "как")
                {
                    arrayStr[i] = "";
                    howbool = true;
                    break;
                }
            }
            for (int i = 0; i < how.Length; i++)
            {
                for (int j = 0; j < arrayStr.Length; j++)
                {
                    if (arrayStr[j] == how[i] && howbool)
                    {
                        arrayStr[j] = "";
                        return "Спасибо! Все отлично!\n" + Bot(Collector(arrayStr));
                    }
                }
            }

            return "";
        }
    }
}
