﻿using System.Collections.Generic;
using System.Linq;
using WebApplication2.Interfaces;

namespace WebApplication2.Services
{
    using Mocks;
    using Models;
    using Interfaces;

    public class NewsService : MockNews
    {
        private readonly MockNews _mockNews;
        public NewsService()
        {
            this._mockNews = new MockNews();
        }
        public IEnumerable<News> GetNews()
        {
            return _mockNews.AllNews;
        }

        public void AddNews(News news)
        {
            MockNews.ListOfNews.Add(news);
        }
    }
}