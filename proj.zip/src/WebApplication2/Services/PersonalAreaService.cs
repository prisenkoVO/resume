﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Services
{
    using Interfaces;
    using Mocks;
    using Models;
    public class PersonalAreaService
    {
        private readonly IPersonalArea personalArea;
        public PersonalAreaService()
        {
            this.personalArea = new MockPersonalArea();
        }

        public IEnumerable<PersonalArea> GetUsers()
        {
            return personalArea.AllPersonalData;
        }
    }
}
