﻿using System.Linq;
using System.Collections.Generic;


namespace WebApplication2.Services
{
    using Mocks;
    using Models;
    using Interfaces;

    public class UsersService
    {
        private readonly IUser Users;

        public UsersService()
        {
            this.Users = new MockUser();
        }

        public IEnumerable<User> GetUsers()
        {
            return this.Users.AllUsers;
        }

        public IEnumerable<User> GetUsersByRole(long roleId)
        {
            return this.Users.AllUsers.Where(item => item?.Roles?.FirstOrDefault(role => role.Id == roleId) != null);
        }
    }
}
