// map 
const arr = [1, 2, 3, 4, 5]
const mapFunction = (arr, callback) => {
    const result = []

    for (let i = 0; i < arr.length; i++) {
        const elem = callback(arr[i])
        result.push(elem)
    }

    return result
}

const filter = (arr, callback) => {
    const result = []

    for (let i = 0; i < arr.length; i++) {
        const checkElem = callback(arr[i]);
        if (checkElem === elem) result.push(elem)
    }


    return result
}

const reduce = (arr, sum, defaultValue = 0, callback) => {
    for (let i = 0; i < arr.length; i++) {
        sum += callback(arr[i]);
    }

    return sum += defaultValue;
}


reduce([1,2,3], (sum, elem) => sum + elem, 0)