window.onload = () => {
    // Toggle menu  bar
    // TODO: refactor this file
    // TODO: Rewiew this file
    const menuToggle = document.querySelector('#menu_toggle'); // checkbox for toggle
    menuToggle.addEventListener('change', evt => {
        const checked = evt.target.checked; // get checkbox state
        const menu = document.querySelector('.menu'); // Menu sidebar
        const menuBorderTriangle = document.querySelector('.avatar-icon');

        if (checked) {
            menu.style.display = 'block'
            menu.style.opacity = '1'
        } else {
            menu.style.opacity = '0'
            setTimeout(() => {
                menu.style.display = 'none'
            }, 550)
        }

        menuBorderTriangle.classList.toggle('avatar-triangle', checked)
    });

    // Modal window events start
    // TODO: rename this vars
    const add_button = document.querySelector(".news button")
    const modalWindow = document.querySelector(".modal-window")
    const closeButton = document.querySelector(".modal-window__center__close")
    let modalWindowOpen = false;


    function block_window(bul_variable) {
        if (bul_variable == true)
            document.body.style.overflowY = "hidden";
        else
            document.body.style.overflowY = "visible";
    };
    function closeModalWindow() {
        modalWindow.style.display = "none";
        modalWindowOpen = false
        block_window(modalWindowOpen)
    }


    add_button.addEventListener("click", () => {
        modalWindow.style.display = "block"
        modalWindowOpen = true
        block_window(modalWindowOpen)

    })


    window.addEventListener("keyup", (event) => {
        if (event.key == "Escape" && modalWindowOpen == true)
            closeModalWindow(modalWindowOpen)
    })

    window.addEventListener("click", (event) => {
        if (event.target == modalWindow) {
            modalWindow.style.display = "none";
            modalWindowOpen = false
            block_window(modalWindowOpen)
        }
    })

    close_button.addEventListener("click", closeModalWindow)
    // Modal window events end

    // Filter events start

    const filterSection = $('.page_filter');
    const filterIcon = $('.filter-icon');
    let filterToggle = false;

    filterIcon.addEventListener('click', () => {
        filterToggle = !filterToggle;

        if (filterToggle) {
            filterSection.style.display = 'block'
        } else {
            filterSection.style.display = 'none'
        }
    })
    // Filter events end

    //TODO : refactor this code
    const context = this;
    (function () {

        function trackScroll() {
            const scrolled = window.pageYOffset;
            const coords = document.documentElement.clientHeight;

            if (scrolled > 400) {
                goTopBtn.classList.add('back_to_top-show');
            }
            if (scrolled < 400) {
                goTopBtn.classList.remove('back_to_top-show');
            }
        }

        function backToTop() {
            if (context.pageYOffset > 0) {
                context.scrollBy(0, -80);
                setTimeout(backToTop, 0);
            }
        }

        context.addEventListener('scroll', trackScroll);
        document.querySelector('.back_to_top').addEventListener('click', backToTop);
    })
}