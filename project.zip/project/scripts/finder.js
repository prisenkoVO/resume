var arr = ["JavaScript", "C#", "Angular", "Python", "Java", "Web", "ingos", "ingosstrakh", "Ingoscode"]
arr.sort()

function find(obj) {
    const reg = new RegExp('^' + obj.value, 'i'),
        t = document.getElementById('');
    t.innerHTML = '';
    t.style.visibility = "hidden";
    if (obj.value.length > 0)
        for (var i = 0; i < arr.length; i++) {
            if (reg.test(arr[i])) {
                t.innerHTML = arr[i];
                t.style.visibility = "visible";
                break;
            }
        }
}

function hint() {
    const a = document.getElementById('finder').value = document.getElementById('hint').innerHTML;
    document.getElementById('hint').innerHTML = '';
    document.getElementById("hint").style.visibility = "hidden";
}