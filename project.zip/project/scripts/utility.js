// File with utility functions 
// DONT WRAP WITH THE IIFE
const $ = (selector) => document.querySelector(selector)

const $All = (selector) => document.querySelectorAll(selector)
